<?php
/**
 * Options for the contact plugin
 *
 * @author Elliot Johnson <elliotj@elliotj.com> 
 */

$meta['default'] = array('string');
$meta['profile1'] = array('string');
$meta['profile2'] = array('string');
$meta['profile3'] = array('string');
$meta['profile4'] = array('string');
