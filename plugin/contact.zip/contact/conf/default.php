<?php
/**
 * Options for the contact plugin
 *
 * @author Elliot Johnson <elliotj@elliotj.com> 
 */

$conf['default'] = ''; //default e-mail address
$conf['profile1'] = ''; //profile1 e-mail address
$conf['profile2'] = ''; //profile2 e-mail address
$conf['profile3'] = ''; //profile3 e-mail address
$conf['profile4'] = ''; //profile4 e-mail address
