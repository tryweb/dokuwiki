<?php
/*
 * ITrackViewer plugin, default configuration settings
 *
 * @author   Juergen A.Lamers <jaloma.ac@googlemail.com>
 * @updater	 Jonathan Tsai <tryweb@ichiayi.com>
 */
$conf['js_ok'] = false;
$conf['key'] = 'ABQIAAAApkxzUZhHW5wXMMdcO_FV3xQe3UNPinsE34fJKznQKjUdy8MssxQFBsDr_C2L5ddfHnI0332d8iJLIA';
$conf['script'] = 'http://maps.google.com/maps?file=api&amp;v=2.x&amp;key=';
$conf['everykey'] = 'ABQIAAAA_7777777777gggggggggghhhhhhhh-BzBD--2222222222ffffffffffddddddddddGGGGGGGGGGoo';
$conf['picasakey'] = 'Gv1111111111jjjjjjjj';
