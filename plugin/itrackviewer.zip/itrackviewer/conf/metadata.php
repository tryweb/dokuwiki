<?php
/*
 * ITrackViewer plugin, configuration metadata
 *
 * @author   Juergen A. Lamers <jaloma.ac@googlemail.com>
 * @updater	 Jonathan Tsai <tryweb@ichiayi.com>
 */
$meta['js_ok']  = array('onoff');
$meta['key']    = array('string');
$meta['script'] = array('string');
$meta['everkey'] = array('string');
$meta['picasakey'] = array('string');
