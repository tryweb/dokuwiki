<?php
/**
 * German language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Juergen A. Lamers <jaloma.ac@googlemail.com>
 */
 
// for the configuration manager
$lang['js_ok']  = 'Erlaube javascript urls';
$lang['pagedefs'] = 'Mapping Pagedefs';
$lang['baseurl'] = 'BaseUrl';
$lang['target'] = 'Zielfenster';
$lang['key'] = 'Schlüssel für GoogleMap';
$lang['script'] = 'Aufruf des GoogleMap-Script';
