<?php

$lang['sort'] = 'Sort by this column';
$lang['next'] = 'Next page';
$lang['prev'] = 'Previous page';

$lang['tagfilter'] = "Show pages matching '%s'";
$lang['related']   = 'Related pages:';
