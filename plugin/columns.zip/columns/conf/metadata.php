<?php
/**
 * Metadata for configuration manager plugin
 * Additions for the datefilter plugin
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Mykola Ostrovskyy <spambox03@mail.ru>
 */

$meta['kwcolumns'] = array('string');
$meta['kwnewcol']  = array('string');
$meta['wrapnewcol']  = array('onoff');
