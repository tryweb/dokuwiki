<?php
/**
 * Configuration defaults
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Mykola Ostrovskyy <spambox03@mail.ru>
 */

$conf['wrapnewcol'] = 1;
