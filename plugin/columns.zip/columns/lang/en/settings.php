<?php
/**
 * English language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Mykola Ostrovskyy <spambox03@mail.ru>
 */

$lang['kwcolumns'] = 'Columns tag (default: columns); must be specified within angle brackets (&lt;columns&gt;...&lt;/columns&gt;)';
$lang['kwnewcol']  = 'New column tag (default: newcolumn)';
$lang['wrapnewcol']  = 'Wrap the new column tag in angle brackets (&lt;newcolumn&gt;)';
