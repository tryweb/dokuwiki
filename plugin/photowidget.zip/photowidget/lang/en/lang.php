<?php
$lang['photowidget'] = 'PhotoWidget';
