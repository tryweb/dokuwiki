<?php
 
$lang['btn_submit'] = 'Skicka';
 
//Setup VIM: ex: et ts=4 enc=utf-8 :
?>