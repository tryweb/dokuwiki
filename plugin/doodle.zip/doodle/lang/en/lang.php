<?php

$lang['btn_submit'] = 'Submit';

//Setup VIM: ex: et ts=4 enc=utf-8 :
?>
