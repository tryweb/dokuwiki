<?php
/**
 * translation by Raimon  <gwindor@auna.com>
 */

$lang['btn_submit'] = 'Envia';

//Setup VIM: ex: et ts=4 enc=utf-8 :
?>
