<?php

$lang['btn_submit'] = 'Invia';

?>
