<?php

$lang['btn_submit'] = '送出';

//Setup VIM: ex: et ts=4 enc=utf-8 :
?>