<?php
 
$lang['btn_submit'] = 'Envoyer';
 
?>