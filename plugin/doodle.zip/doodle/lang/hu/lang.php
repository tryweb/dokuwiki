<?php
 
  $lang['btn_submit'] = 'Szavazok';
 
?>