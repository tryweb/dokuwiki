<?php
 
$lang['btn_submit'] = 'Verstuur';
 
//Setup VIM: ex: et ts=4 enc=utf-8 :
?>