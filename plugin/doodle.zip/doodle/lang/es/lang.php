<?php
 
  $lang['btn_submit'] = 'Enviar';
 
?>