<?php

$lang['btn_submit'] = '提交';

//Setup VIM: ex: et ts=4 enc=utf-8 :
?>