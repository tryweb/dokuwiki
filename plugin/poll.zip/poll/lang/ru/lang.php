<?php

/* @author  Gleb Trjemetsky  <bozman@cybergal.com> */

$lang['btn_vote'] = 'Проголосовать';

//Setup VIM: ex: et ts=4 enc=utf-8 :
