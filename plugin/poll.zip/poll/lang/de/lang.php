<?php

$lang['btn_vote'] = 'Abstimmen';

//Setup VIM: ex: et ts=4 enc=utf-8 :
